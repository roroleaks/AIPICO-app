import type { AuditableRef } from "./relevance.ts";
import { checkCitations, extractInTextCites, extractNumericCites, formatReference, foldName } from "./relevance.ts";
import { normalizeDoi, type EvidenceWarning } from "./evidence-set.ts";

/**
 * Narrative fields the reader can see. Citation integrity has to hold across all of them: a
 * citation stranded in the conclusion is the same defect as one stranded in the discussion,
 * because the reader still meets an attribution the bibliography does not support.
 */
export const NARRATIVE_FIELDS = ["abstract", "introduction", "discussion", "conclusion"] as const;
export type NarrativeField = (typeof NARRATIVE_FIELDS)[number];

export interface DeliverableIntegrityInput {
  /** Every narrative field that can reach a deliverable. */
  fields?: Record<string, string>;
  /** The reference list as it will be published. */
  references?: string[];
  /** Exactly the records behind `references`: the claim-specific retained evidence set. */
  retainedRecords?: AuditableRef[];
  /**
   * Reference strings a deliverable is about to emit (PDF/Word/clipboard). When present these
   * must resolve into `retainedRecords`, which is what stops an export reintroducing a source
   * the claim filter rejected.
   */
  exportReferences?: string[];
  /** Canonical keys the evidence set allows, when available, for stricter resolution. */
  allowedKeys?: Set<string>;
  citationMap?: Map<string, AuditableRef>;
  title?: string;
  sections?: Array<{ heading?: string; blocks?: string[] } | Record<string, unknown>>;
  retainedReferences?: AuditableRef[];
  citationStyle?: string;
  retrievedCount?: number;
  retainedCount?: number;
  excludedCount?: number;
}

export interface DeliverableIntegrityResult {
  ok: boolean;
  accountingMismatch?: string;
  blanketCitations?: string[];
  /** Citations naming an author/year with no record behind it. */
  unsupportedCitations: string[];
  /** Citations with no matching entry in the published reference list. */
  orphanCitations: string[];
  /** Published references that nothing in the narrative cites. */
  uncitedReferences: string[];
  /** Published references that resolve to no retained record. */
  unresolvedReferences: string[];
  /** Emitted deliverable references absent from the retained evidence set. */
  extraExportReferences: string[];
  duplicateCitationKeys: string[];
  /**
   * Entries the caller supplied with the wrong type. The gate reports these instead of
   * throwing, because it is the last server-side check before a durable, citable artifact is
   * produced and it receives an untrusted request body verbatim.
   */
  malformedReferences: string[];
  warnings: EvidenceWarning[];
}

/** Canonical key of a reference *string*, independent of which record happens to match it. */
function referenceKey(ref: string): string {
  // Defensive: this key is also reached from the duplicate-detection loop, which walks the
  // caller's array before any element guard has run. Coercing here means a non-string can
  // never reach foldName, which assumes a real string.
  const raw = String(ref).replace(/^\[?\d+\]?[\.\)]?\s*/, "");
  const doi = normalizeDoi((raw.match(/10\.\d{4,9}\/[^\s"'<>,;)\]]+/i) || [])[0] || "");
  if (doi) return `doi:${doi}`;
  const pmid = (raw.match(/\bPMID:?\s*(\d{6,9})\b/i) || [])[1]
    || (/pubmed\.ncbi\.nlm\.nih\.gov\/(\d{6,9})/.exec(raw) || [])[1];
  if (pmid) return `pmid:${pmid}`;
  return `str:${foldName(raw).slice(0, 80)}`;
}

/**
 * Surnames an in-text citation may legitimately use for a record.
 *
 * This mirrors the resolution the evidence pipeline itself performs (`findKeyForCitation` and
 * `checkCitations` both match any surname on the record). The gate deliberately does not tighten
 * it: a gate that resolves citations more strictly than the code it gates will reject output the
 * pipeline considers sound, and it will disagree with the reference list it is meant to verify.
 * Strictness about what may be cited belongs to the claim filter and the reconciliation
 * fixpoint, which are directly tested; this function's job is to confirm the deliverables carry
 * exactly the set those stages approved.
 */
function citingSurnames(rec: AuditableRef): string[] {
  const fromAuthors = String(rec.authors || "")
    .split(/[,;\s]+/)
    .filter(Boolean)
    .map(a => foldName(a));
  const fromFormatted = formatReference(rec).split(/[,;]/).map(s => foldName(s)).filter(Boolean);
  return [...new Set([...fromAuthors, ...fromFormatted])].filter(s => s.length > 1);
}

function citationMatchesRecord(author: string, year: string, rec: AuditableRef): boolean {
  if (String(rec.year || "") !== String(year || "")) return false;
  return citingSurnames(rec).includes(foldName(author));
}

/**
 * A reference string is trusted only when a retained record accounts for it, preferring the
 * identifiers a publisher guarantees over author-name resemblance.
 */
function referenceIsBackedBy(ref: string, retained: AuditableRef[]): boolean {
  const target = String(ref).replace(/^\[?\d+\]?[\.\)]?\s*/, "");
  const refDoi = referenceKey(target).startsWith("doi:") ? referenceKey(target).slice(4) : "";
  const refPmid = referenceKey(target).startsWith("pmid:") ? referenceKey(target).slice(5) : "";
  const refFolded = foldName(target);
  return retained.some(rec => {
    const recDoi = normalizeDoi(rec.doi);
    if (refDoi && recDoi) return refDoi === recDoi;
    const recPmid = String(rec.pmid || "").trim();
    if (refPmid && recPmid) return refPmid === recPmid;
    // Only fall back to text similarity when neither side carries a usable identifier, so a
    // DOI-bearing reference can never be "backed" by an unrelated record with a similar title.
    if (recDoi || recPmid) return false;
    const canonical = foldName(formatReference(rec));
    return (canonical.length > 40 && refFolded.includes(canonical.slice(0, 60)))
      || (Boolean(rec.title) && refFolded.includes(foldName(String(rec.title)).slice(0, 60)));
  });
}

export function validateDeliverableIntegrity(input: DeliverableIntegrityInput): DeliverableIntegrityResult {
  // This gate is reachable directly from an HTTP request body, so it must not assume its input
  // is well formed. Every list and record field is normalized first: a caller that posts
  // `references: [{citation: "Smith 2020"}]` gets a structured refusal naming the offending
  // entry, rather than an exception that surfaces as an opaque HTTP 500. The refusal still
  // happens, because a malformed entry is exactly the case where the caller cannot be trusted
  // to have assembled the reference list from retained evidence.
  const inp = (input || {}) as DeliverableIntegrityInput;
  const malformedReferences: string[] = [];

  const describe = (v: unknown): string =>
    v === null ? "null" : Array.isArray(v) ? "array" : typeof v;

  const asStrings = (list: unknown, label: string): string[] => {
    if (list === undefined || list === null) return [];
    if (!Array.isArray(list)) {
      malformedReferences.push(`${label} must be an array of strings, received ${describe(list)}`);
      return [];
    }
    const out: string[] = [];
    list.forEach((v, i) => {
      if (typeof v === "string") { out.push(v); return; }
      malformedReferences.push(`${label}[${i}] must be a string, received ${describe(v)}`);
    });
    return out;
  };

  const fields: Record<string, string> = {};
  for (const [k, v] of Object.entries((inp.fields || {}) as Record<string, unknown>)) {
    if (typeof v === "string") { fields[k] = v; continue; }
    malformedReferences.push(`fields.${k} must be a string, received ${describe(v)}`);
  }
  const narrative = Object.keys(fields).map(n => fields[n]).join(" ");
  const references = asStrings(inp.references, "references");
  const exportReferences = asStrings(inp.exportReferences, "exportReferences");
  const retained: AuditableRef[] = (
    Array.isArray(inp.retainedRecords)
      ? inp.retainedRecords
      : Array.isArray(inp.retainedReferences)
      ? inp.retainedReferences
      : []
  ).filter((r): r is AuditableRef => !!r && typeof r === "object");

  const unsupportedCitations: string[] = [];
  const seenUnsupported = new Set<string>();
  const citedRecordIndexes = new Set<number>();

  for (const c of extractInTextCites(narrative)) {
    const label = `${c.author} ${c.year}`.trim();
    if (!label) continue;
    const matching = retained
      .map((rec, i) => ({ rec, i }))
      .filter(({ rec }) => citationMatchesRecord(c.author, c.year, rec));
    if (matching.length === 0) {
      if (!seenUnsupported.has(label)) {
        seenUnsupported.add(label);
        unsupportedCitations.push(label);
      }
      continue;
    }
    matching.forEach(({ i }) => citedRecordIndexes.add(i));
  }

  // Also support Vancouver numerical citations [1], [2], etc.
  const { citedNumbers } = extractNumericCites(narrative);
  for (const num of citedNumbers) {
    const idx = num - 1;
    if (idx >= 0 && idx < retained.length) {
      citedRecordIndexes.add(idx);
    } else {
      const label = `[${num}]`;
      if (!seenUnsupported.has(label)) {
        seenUnsupported.add(label);
        unsupportedCitations.push(label);
      }
    }
  }

  // Orphan and uncited detection is delegated to the same checker the pipeline reconciles with,
  // so the gate reports exactly the defects that survived reconciliation rather than a second,
  // divergent opinion about them.
  const checks = checkCitations(narrative, references);
  const orphanCitations = [...checks.orphans];
  // Whether a reference is cited at all is only knowable when the narrative travels with it. A
  // references-only export (the reference-list PDFs, a Word bibliography) legitimately arrives
  // without prose, and treating every reference there as uncited would refuse a correct export.
  const hasNarrative = narrative.trim().length > 0;
  const uncitedReferences = hasNarrative ? [...checks.uncited] : [];

  const unresolvedReferences = references.filter(r => !referenceIsBackedBy(r, retained));
  const extraExportReferences = exportReferences.filter(er => !referenceIsBackedBy(er, retained));

  const seenKeys = new Set<string>();
  const duplicateCitationKeys: string[] = [];
  for (const ref of references) {
    const key = referenceKey(ref);
    if (seenKeys.has(key) && !duplicateCitationKeys.includes(key)) duplicateCitationKeys.push(key);
    seenKeys.add(key);
  }

  let accountingMismatch: string | undefined = undefined;
  if (
    typeof inp.retrievedCount === "number" &&
    typeof inp.retainedCount === "number" &&
    typeof inp.excludedCount === "number"
  ) {
    if (inp.retrievedCount !== inp.retainedCount + inp.excludedCount) {
      accountingMismatch = `Retrieval accounting mismatch: retrieved (${inp.retrievedCount}) != retained (${inp.retainedCount}) + excluded (${inp.excludedCount})`;
    }
  }

  const blanketCitations: string[] = [];
  if (references.length >= 4) {
    const allSurnames = new Set<string>();
    for (const rec of retained) {
      for (const s of citingSurnames(rec)) {
        if (s.length >= 3) allSurnames.add(s);
      }
    }

    for (const [fieldName, fieldText] of Object.entries(fields)) {
      if (typeof fieldText !== "string") continue;
      const sentences = fieldText
        .split(/(?<=[.!?])\s+|\n{1,}/)
        .map(s => s.trim())
        .filter(s => s.length > 0);

      for (const sentence of sentences) {
        const { citedNumbers, rawBrackets } = extractNumericCites(sentence);
        if (citedNumbers.size >= Math.ceil(references.length * 0.75)) {
          const lowerSentence = foldName(sentence);
          const namesStudy = Array.from(allSurnames).some(nm => {
            const rx = new RegExp(`\\b${nm}\\b`, "i");
            return rx.test(lowerSentence);
          });
          if (!namesStudy) {
            blanketCitations.push(
              `In ${fieldName}: blanket citation [${rawBrackets.join(", ")}] covers ${citedNumbers.size}/${references.length} references on sentence naming no study: "${sentence.slice(0, 80)}..."`
            );
          }
        }
      }
    }
  }

  const ok =
    !accountingMismatch &&
    blanketCitations.length === 0 &&
    unsupportedCitations.length === 0 &&
    orphanCitations.length === 0 &&
    uncitedReferences.length === 0 &&
    unresolvedReferences.length === 0 &&
    extraExportReferences.length === 0 &&
    duplicateCitationKeys.length === 0 &&
    malformedReferences.length === 0;

  return {
    ok,
    accountingMismatch,
    blanketCitations,
    unsupportedCitations,
    orphanCitations,
    uncitedReferences,
    unresolvedReferences,
    extraExportReferences,
    duplicateCitationKeys,
    malformedReferences,
    warnings: []
  };
}
