import { KB, QUESTION_TYPES, SYNONYMS, rationalOutcomes, type Analysis, type Clarification, type Formulation, type SpecialtyKey } from "./kb.ts";
import { buildOutcomeContext, selectOutcomes } from "./outcome-selection.ts";
import { formulateOutcomeVerbPhrase, toInlineCase, resolveKnownOutcome, isAdjuvantIntervention } from "./clinical-semantics.ts";

function normalize(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]/g, "");
}

function singular(t: string): string {
  return t.length > 4 && t.endsWith("s") && !t.endsWith("ss") ? t.slice(0, -1) : t;
}

function canonical(term: string): string {
  const n = normalize(singular(term));
  return SYNONYMS[n] || term;
}

const NORM_SYNONYMS: Record<string, string> = Object.fromEntries(
  Object.entries(SYNONYMS).map(([k, v]) => [normalize(k), v])
);

function matchIn(text: string, list: string[]): string[] {
  const norm = normalize(text);
  const found: string[] = [];
  for (const raw of list) {
    const t = NORM_SYNONYMS[singular(normalize(raw))] || NORM_SYNONYMS[normalize(raw)] || normalize(singular(raw));
    if (t.length >= 4 && norm.includes(t)) {
      found.push(canonical(raw));
    }
  }
  return [...new Set(found)];
}

const FERTILITY_CUES = ["ivf", "icsi", "iui", "infertil", "conception", "fertility", "embryo", "oocyte", "sperm", "ovul", "amh", "implantation", "blastocyst", "recurrent pregnancy loss", "miscarriage"];

export function ruleAnalyze(input: string): Analysis {
  const lower = input.toLowerCase();
  let best: SpecialtyKey[] = [];
  let bestHits = 0;
  for (const key of Object.keys(KB) as SpecialtyKey[]) {
    const hits = matchIn(lower, KB[key].conditions).length * 2 + matchIn(lower, KB[key].interventions).length;
    if (hits > bestHits) { bestHits = hits; best = [key]; }
    else if (hits === bestHits && hits > 0) best.push(key);
  }
  let specKey: SpecialtyKey | null = null;
  if (bestHits > 0) {
    if (best.length === 1) specKey = best[0];
    else if (FERTILITY_CUES.some(w => lower.includes(w))) specKey = best.includes("infertility") ? "infertility" : best[0];
    else specKey = best.includes("gynecology") ? "gynecology" : (best.includes("obstetrics") ? "obstetrics" : best[0]);
  }
  if (!specKey) {
    return {
      specialty: null, specialtyLabel: "Unknown", condition: "", intervention: "",
      comparator: "", questionType: "Therapy / Prevention", framework: "PICO",
      missing: ["condition", "intervention", "comparator", "outcome"],
      interpretation: "Could not map this to a known specialty in offline mode.",
      source: "rules"
    };
  }
  const spec = KB[specKey];
  const conds = matchIn(lower, spec.conditions);
  const ivs = matchIn(lower, spec.interventions);
  const diagWords = ["diagnos", "ultrasound", "mri", "accuracy", "test"];
  const progWords = ["prognos", "predict", "risk of", "likelihood"];
  let qt = QUESTION_TYPES[0];
  if (diagWords.some(w => lower.includes(w))) qt = QUESTION_TYPES[1];
  else if (!ivs.length && !progWords.some(w => lower.includes(w))) qt = QUESTION_TYPES[3];

  const missing: string[] = [];
  if (!conds.length) missing.push("condition");
  if (!ivs.length && qt.framework === "PICO") missing.push("intervention");
  if (ivs.length < 2 && qt.framework === "PICO") missing.push("comparator");
  missing.push("outcome");

  return {
    specialty: specKey,
    specialtyLabel: spec.label,
    condition: conds[conds.length - 1] || "",
    intervention: ivs[ivs.length - 1] || "",
    comparator: ivs.length > 1 ? ivs[ivs.length - 2] : "",
    questionType: qt.type,
    framework: qt.framework,
    missing,
    interpretation: `Recognized ${spec.label} context with ${qt.type} intent.`,
    source: "rules"
  };
}

export function ruleClarify(analysis: Analysis, answered: Record<string, string>): Clarification {
  // These two functions are the fallback for the AI path, so they must never be the thing that
  // throws. `analysis` arrives straight from a request body: `{}`, `[]` and `"x"` are all
  // truthy, reached the old unguarded `analysis.missing.find(...)`, and turned a provider
  // failure into an unhandled TypeError. Normalize defensively; the route separately rejects
  // genuinely malformed input with a 400.
  const a = (analysis || {}) as Partial<Analysis>;
  const ans = (answered || {}) as Record<string, string>;
  // Resolve the specialty against the KB once. A truthy but unrecognized value such as "nope"
  // must collapse to null here, because every downstream KB[...] lookup and rationalOutcomes call
  // would otherwise dereference undefined.
  const specKey: SpecialtyKey | null =
    a.specialty && KB[a.specialty as SpecialtyKey] ? (a.specialty as SpecialtyKey) : null;
  const spec = specKey ? KB[specKey] : null;
  const missing = Array.isArray(a.missing) ? a.missing : [];
  const nextField = missing.find(f => !ans[f]);
  if (!nextField) {
    return { done: true, field: null, questionText: "", options: [], allowFreeText: false, source: "rules" };
  }
  // A missing specialty spec is NOT a reason to stop asking. The old code returned done: true
  // whenever `spec` was null, so an unrecognised clinical area skipped clarification entirely and
  // went straight to ruleFormulate with nothing collected - which then fabricated "Women with the
  // population of interest" as a clinical question. The PICO prompts below need no spec; only the
  // suggested options do, and an empty option list still leaves the free-text answer available.
  const prompts: Record<string, string> = {
    condition: "What is the clinical problem or population?",
    intervention: "What intervention are you considering?",
    comparator: "Compared with what?",
    outcome: "What is your primary outcome?"
  };
  const optionMap: Record<string, string[]> = {
    condition: spec ? spec.conditions : [],
    intervention: spec ? spec.interventions : [],
    comparator: spec ? ["no treatment / placebo", "usual care", ...spec.interventions.slice(0, 5)] : [],
    outcome: spec ? spec.outcomesRanked : []
  };
  let options: string[] = (optionMap[nextField] || []).slice(0, 8);
  let rationale: string | undefined;
  let outcomeSelection: Clarification["outcomeSelection"];
  if (nextField === "outcome") {
    // The outcome field is answered from the ontology rather than from the specialty's flat list,
    // so the recommendation reflects the condition, intervention and comparator already collected.
    const selection = selectOutcomes(buildOutcomeContext(
      {
        specialty: specKey,
        condition: ans.condition || a.condition || "",
        intervention: ans.intervention || a.intervention || "",
        comparator: ans.comparator || a.comparator || "",
        questionType: ans.questionType || a.questionType || ""
      },
      ans,
      { population: ans.population || ans.condition || a.condition || "" }
    ));
    outcomeSelection = selection;
    options = selection.options.map(o => o.label);
    rationale = selection.recommendedOutcome.rationale;
  }
  return {
    done: false,
    field: nextField,
    questionText: prompts[nextField] || `Please specify: ${nextField}`,
    options,
    allowFreeText: true,
    source: "rules",
    rationale,
    outcomeSelection
  };
}

export function normalizeCondition(cond: string): string {
  return cond
    .trim()
    .replace(/^(?:(?:pregnant\s+)?women\s+with|(?:pregnant\s+)?woman\s+with|patients?\s+with)\s+/i, "")
    .trim();
}

export function ruleFormulate(analysis: Analysis, answered: Record<string, string>): Formulation {
  const a = (analysis || {}) as Partial<Analysis>;
  const ans = (answered || {}) as Record<string, string>;
  const cond = (ans.condition || a.condition || "").trim();
  const cleanCond = normalizeCondition(cond);
  const iv = (ans.intervention || a.intervention || "").trim();
  const comp = (ans.comparator || a.comparator || "").trim();

  // Resolve specialty
  const specKey: SpecialtyKey | null =
    a.specialty && KB[a.specialty as SpecialtyKey] ? (a.specialty as SpecialtyKey) : null;
  const spec = specKey ? KB[specKey] : null;

  const missingElements: string[] = [];
  if (!cond) missingElements.push("condition");
  if (!iv) missingElements.push("intervention");

  let effectiveComp = comp;
  if (!effectiveComp) {
    if (specKey === "infertility" && isAdjuvantIntervention(iv)) {
      effectiveComp = `no ${iv} (standard protocol)`;
    } else if (specKey === "obstetrics") {
      effectiveComp = "standard care or expectant management";
    } else {
      effectiveComp = "standard care";
    }
  }

  const rawOut = (ans.outcome || ((a as unknown as Record<string, unknown>).outcome as string) || "").trim();
  const isPlaceholder = !rawOut || /a clinically meaningful outcome|meaningful outcome/i.test(rawOut);

  let out: string;
  if (isPlaceholder) {
    const outcomeLogic = rationalOutcomes(cleanCond, specKey);
    out = outcomeLogic.primary || (spec ? spec.outcomesRanked[0] : "") || "live birth rate";
  } else {
    const resolved = resolveKnownOutcome(rawOut);
    const ivLower = iv.toLowerCase();
    const compLower = effectiveComp.toLowerCase();
    const rawLower = rawOut.toLowerCase();

    const matchesIvOrComp = (ivLower && rawLower === ivLower) || (compLower && rawLower === compLower) || (resolved && (resolved.canonical.toLowerCase() === ivLower || resolved.canonical.toLowerCase() === compLower));

    if (!resolved || !resolved.valid || matchesIvOrComp) {
      missingElements.push("outcome");
      out = "";
    } else {
      out = resolved.canonical || rawOut;
    }
  }

  if (missingElements.length) {
    return {
      framework: (a.framework || "PICO") as Formulation["framework"],
      elements: [],
      finalQuestion: "",
      variants: [],
      scores: [],
      advisories: [],
      searchTerms: { population: "", intervention: "", outcome: "" },
      source: "rules",
      complete: false,
      missingElements
    };
  }

  let finalQuestion: string;
  let elements: { label: string; value: string }[];
  const framework = a.framework || "PICO";
  const actionPhrase = formulateOutcomeVerbPhrase("primary", out) || `improve ${toInlineCase(out)}`;

  switch (framework) {
    case "PICO":
      finalQuestion = `In women with ${toInlineCase(cleanCond)}, does ${toInlineCase(iv)} compared with ${toInlineCase(effectiveComp)} ${actionPhrase}?`;
      elements = [
        { label: "P — Population", value: `Women with ${cleanCond}` },
        { label: "I — Intervention", value: iv },
        { label: "C — Comparator", value: effectiveComp },
        { label: "O — Outcome", value: out }
      ];
      break;
    case "Diagnostic accuracy (PIRD)":
      finalQuestion = `In patients with suspected ${toInlineCase(cleanCond)}, what is the diagnostic accuracy of ${iv} compared with the reference standard?`;
      elements = [
        { label: "P — Population", value: `Patients with suspected ${cleanCond}` },
        { label: "I — Index test", value: iv },
        { label: "R — Reference standard", value: "Standard reference test" },
        { label: "D — Accuracy outcomes", value: "Sensitivity and specificity" }
      ];
      break;
    default:
      finalQuestion = `In women with ${toInlineCase(cleanCond)}, does ${toInlineCase(iv)} compared with ${toInlineCase(effectiveComp)} ${actionPhrase}?`;
      elements = [
        { label: "P — Population", value: `Women with ${cleanCond}` },
        { label: "I — Intervention", value: iv },
        { label: "C — Comparator", value: effectiveComp },
        { label: "O — Outcome", value: out }
      ];
  }
  const scores = [
    { name: "Population", value: cond ? 18 : 8 },
    { name: "Intervention/Exposure", value: iv ? 19 : 10 },
    { name: "Comparator", value: effectiveComp ? 18 : 12 },
    { name: "Outcome", value: 14 },
    { name: "Specificity", value: 17 }
  ];
  const advisories: string[] = [];
  const logic = rationalOutcomes(cond, specKey);
  if (out.toLowerCase() === logic.primary.toLowerCase()) {
    scores[3] = { name: "Outcome", value: 20 };
  } else if (logic.alternatives.some(o => o.toLowerCase() === out.toLowerCase())) {
    scores[3] = { name: "Outcome", value: 17 };
    advisories.push(`'${out}' is a reasonable outcome, but '${logic.primary}' is the most patient-centered for this scenario.`);
  } else {
    scores[3] = { name: "Outcome", value: scores[3].value };
    advisories.push(`'${out}' is not the most appropriate outcome for this scenario. Consider '${logic.primary}' — ${logic.rationale.replace(/\.$/, "")}.`);
  }
  if (/miscarriage rate|implantation rate|clinical pregnancy rate/.test(out.toLowerCase())) {
    advisories.push("Report pregnancy-related outcomes as live birth or ongoing pregnancy where possible — biochemical endpoints are poor surrogates.");
  }
  // Filter altOutcomes by specialty and condition
  const rawAlternatives = [
    ...(logic.alternatives || []),
    ...(spec ? spec.outcomesRanked : [])
  ];

  const seenOutcomes = new Set<string>([out.toLowerCase().trim()]);
  const altOutcomes: string[] = [];

  for (const alt of rawAlternatives) {
    const trimmed = alt.trim();
    const lower = trimmed.toLowerCase();
    if (!trimmed || seenOutcomes.has(lower)) continue;

    // Exclude generic symptom-resolution outcome for infertility
    if (specKey === "infertility" || /infertility|ivf|poor responder|icsi|dor|azoospermia/i.test(cond)) {
      if (/symptom|resolution of the presenting symptom|presenting symptom/i.test(lower)) continue;
      if (/poor responder|poor ovarian response|ivf/i.test(cond) && /ovulation rate/i.test(lower)) continue;
    }

    seenOutcomes.add(lower);
    altOutcomes.push(trimmed);
  }

  const variants = [
    { question: finalQuestion, rationale: "Recommended default — uses your chosen outcome." },
    ...altOutcomes.map((o, idx) => {
      const verbType = idx === 0 ? "secondary" : "subgroup";
      let vQuestion: string;
      const vAction = formulateOutcomeVerbPhrase(verbType, o) || `improve ${toInlineCase(o)}`;
      if (framework === "Diagnostic accuracy (PIRD)") {
        vQuestion = finalQuestion.replace(new RegExp(out.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i"), o);
      } else {
        vQuestion = `In women with ${toInlineCase(cleanCond)}, does ${toInlineCase(iv)} compared with ${toInlineCase(effectiveComp)} ${vAction}?`;
      }
      return {
        question: vQuestion,
        rationale: `Same question evaluating ${toInlineCase(o)} as a ${idx === 0 ? "secondary" : "comparative"} outcome.`
      };
    })
  ].slice(0, 4);
  return {
    framework: framework as Formulation["framework"],
    elements,
    finalQuestion,
    variants,
    scores,
    advisories,
    searchTerms: { population: cleanCond, intervention: iv, outcome: out },
    source: "rules",
    complete: true,
    missingElements: []
  };
}
