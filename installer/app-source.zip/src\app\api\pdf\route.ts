import { NextResponse } from "next/server";
import { NextRequest } from "next/server";
import { z } from "zod";
import { validateDeliverableIntegrity } from "@/lib/deliverable-integrity";
import type { AuditableRef } from "@/lib/relevance";
import { buildPdfBuffer, buildWorkflowPdf } from "@/lib/pdf-generator";
import { provenanceSchema } from "@/lib/provenance";
import { isAllowedOrigin, corsHeaders } from "@/lib/security-headers";
import { checkRateLimit } from "@/lib/rate-limiter";

export const runtime = "nodejs";
export const maxDuration = 20;

const picoRowSchema = z.object({
  label: z.string().max(200),
  value: z.string().max(1000),
});

const pdfSectionSchema = z.object({
  heading: z.string().max(200).optional().nullable(),
  blocks: z.array(z.string().max(10000)),
});

const auditableRefSchema = z.object({
  pmid: z.string().max(50).optional().nullable(),
  title: z.string().max(1000),
  authors: z.string().max(1000).optional().nullable(),
  year: z.string().max(50).optional().nullable(),
  journal: z.string().max(500).optional().nullable(),
  doi: z.string().max(500).optional().nullable(),
  url: z.string().max(1000).optional().nullable(),
  context: z.string().max(20000).optional().nullable(),
  source: z.string().max(100).optional().nullable(),
  crossrefId: z.string().max(100).optional().nullable(),
  openAlexId: z.string().max(100).optional().nullable(),
});

const workflowWordSchema = z.object({
  word: z.string().min(1).max(80),
  role: z.enum(["population", "intervention", "comparator", "outcome"])
});

const workflowScreeningStatsSchema = z.object({
  retrieved: z.number().int().nonnegative(),
  screened: z.number().int().nonnegative(),
  relaxationLevel: z.number().int().min(0).max(2),
  excludedCount: z.number().int().nonnegative()
});

const workflowPaperSchema = z.object({
  rank: z.number().int().positive(),
  relevancePct: z.number().int().min(0).max(100),
  title: z.string(),
  authors: z.string(),
  journal: z.string(),
  year: z.string(),
  design: z.string(),
  matchedElements: z.array(z.string())
});

const workflowSchema = z.object({
  words: z.array(workflowWordSchema).min(3).max(5),
  category: z.enum(["established", "conflicting", "gap"]),
  phrase: z.string().min(1).max(240),
  screeningStats: workflowScreeningStatsSchema,
  papers: z.array(workflowPaperSchema).max(50)
});

const pdfPayloadSchema = z.object({
  docType: z.string().max(100).optional().nullable(),
  title: z.string().min(1).max(500).optional().nullable(),
  meta: z.string().max(500).optional().nullable(),
  citationStyle: z.enum(["vancouver", "apa", "harvard"]).optional().nullable(),
  pico: z.array(picoRowSchema).optional().nullable(),
  outcomes: z.array(z.string().max(500)).optional().nullable(),
  keywords: z.array(z.string().max(100)).optional().nullable(),
  sections: z.array(pdfSectionSchema).optional().nullable(),
  references: z.array(z.string().max(2000)).optional().nullable(),
  retainedReferences: z.array(auditableRefSchema).optional().nullable(),
  provenance: provenanceSchema.optional().nullable(),
  workflow: workflowSchema.optional().nullable()
});

const BODY_MAX = 400_000;

/** Handle CORS preflight for /api/pdf */
export async function OPTIONS(req: NextRequest): Promise<NextResponse> {
  const origin = req.headers.get("origin");
  if (isAllowedOrigin(origin)) {
    return new NextResponse(null, { status: 204, headers: corsHeaders(origin!) });
  }
  return new NextResponse(null, { status: 403 });
}

export async function POST(req: NextRequest): Promise<NextResponse> {
  const origin = req.headers.get("origin");
  const cors = isAllowedOrigin(origin) ? corsHeaders(origin!) : {};

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "127.0.0.1";
  const limit = await checkRateLimit(ip, "pdf", 10, 60);
  if (!limit.success) {
    return NextResponse.json(
      { error: "Too many requests. Please wait and try again." },
      {
        status: 429,
        headers: {
          ...cors,
          "Retry-After": String(Math.ceil((limit.reset - Date.now()) / 1000)),
        },
      }
    );
  }

  try {
    const raw = await req.text();
    if (!raw || raw.length > BODY_MAX) {
      return NextResponse.json({ error: "Payload too large or empty." }, { status: 400, headers: cors });
    }
    // Malformed JSON is a client error. Letting JSON.parse throw into the outer catch reported
    // it as HTTP 500 "PDF generation failed", which told the caller to retry a request that
    // could never succeed and buried the real cause in server logs.
    let parsed: unknown;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return NextResponse.json({ error: "Invalid JSON body." }, { status: 400, headers: cors });
    }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      return NextResponse.json({ error: "Request body must be a JSON object." }, { status: 400, headers: cors });
    }

    const parseResult = pdfPayloadSchema.safeParse(parsed);
    if (!parseResult.success) {
      return NextResponse.json(
        { error: "Invalid parameters: " + parseResult.error.issues.map(e => e.message).join(", ") },
        { status: 400, headers: cors }
      );
    }
    const body = parseResult.data;

    if (body.workflow) {
      const pdf = await buildWorkflowPdf(body.workflow);
      const safe = String(body.workflow.phrase).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80) || "workflow-summary";

      return new NextResponse(new Uint8Array(pdf), {
        headers: {
          ...cors,
          "Content-Type": "application/pdf",
          "Content-Disposition": `attachment; filename="${safe}.pdf"`,
          "Cache-Control": "no-store"
        }
      });
    }

    if (!body.title) {
      return NextResponse.json({ error: "Document title is required." }, { status: 400, headers: cors });
    }

    // A caller that asks for a document with neither narrative sections nor references is asking
    // for a titled PDF with no content, which is misleading rather than merely empty. This must
    // not depend on whether `references` was sent as [] or omitted entirely: the two mean the
    // same thing to the reader, so they are treated the same way here. Exports that legitimately
    // have no references, such as the evidence map, carry sections and are unaffected.
    const hasReferences = Array.isArray(body.references) && body.references.length > 0;
    const hasSections = Array.isArray(body.sections) && body.sections.length > 0;
    const hasPico = Array.isArray(body.pico) && body.pico.length > 0;
    if (!hasReferences && !hasSections && !hasPico) {
      return NextResponse.json(
        { error: "No references, sections, or PICO elements available to export." },
        { status: 400, headers: cors }
      );
    }
    // Server-side half of the parity gate. The browser already checks this, but the browser is
    // not the trust boundary: a caller can post to this endpoint directly, and a PDF is the most
    // durable and most citable artifact this app produces. Every reference emitted must be
    // accountable to a retained record the claim filter approved.
    if (Array.isArray(body.references) && body.references.length > 0) {
      const integrity = validateDeliverableIntegrity({
        fields: {},
        references: body.references,
        retainedRecords: Array.isArray(body.retainedReferences) ? (body.retainedReferences as unknown as AuditableRef[]) : [],
        exportReferences: body.references
      });
      if (!integrity.ok) {
        return NextResponse.json(
          {
            error: integrity.malformedReferences.length
              ? "Export refused: the reference list contained malformed entries."
              : "Export refused: references did not match the validated evidence set.",
            integrity
          },
          { status: 422, headers: cors }
        );
      }
    }

    const title = String(body.title).trim();
    const pdf = await buildPdfBuffer(body);
    const safe = String(title).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80) || "document";

    return new NextResponse(new Uint8Array(pdf), {
      headers: {
        ...cors,
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${safe}.pdf"`,
        "Cache-Control": "no-store"
      }
    });
  } catch (e) {
    console.error("PDF generation failed:", e);
    return NextResponse.json({ error: "PDF generation failed. Please retry." }, { status: 500, headers: cors });
  }
}
