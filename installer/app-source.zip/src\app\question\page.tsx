"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatedProcessingIndicator } from "@/components/AnimatedProcessingIndicator";
import { KB, type Analysis, type Formulation, type SpecialtyKey } from "@/lib/kb";
import {
  buildOutcomeContext,
  selectOutcomes
} from "@/lib/outcome-selection";
import { sget, sset, resetSession, KEYS } from "@/lib/session";
import { readSessionInput, sessionSearchText } from "@/lib/clinical-input";
import { extractPicoFromQuestion, type ExtractedPico } from "@/lib/pico-parser";
import type { CitationStyle } from "@/lib/citation-formatter";

interface GapSnapshot {
  topic?: string;
  specialty?: string;
  known?: Array<{ point?: string; references?: Array<{ title?: string }> }>;
  uncertain?: Array<{ point?: string; references?: Array<{ title?: string }> }>;
  gaps?: Array<{ gap?: string }>;
  suggestedQuestions?: Array<{ question: string; rationale: string }>;
}

interface RenderedOutcome {
  id: string;
  label: string;
  category: string;
  rationale: string;
}

export default function QuestionPage() {
  const router = useRouter();
  const [extractedPico, setExtractedPico] = useState<ExtractedPico | null>(null);
  const [outcomeOptions, setOutcomeOptions] = useState<RenderedOutcome[]>([]);
  const [recommendedId, setRecommendedId] = useState<string>("");
  const [recommendedRationale, setRecommendedRationale] = useState<string>("");
  const [selectedOutcome, setSelectedOutcome] = useState<string>("");
  const [customOutcome, setCustomOutcome] = useState<string>("");
  const [citationStyle, setCitationStyle] = useState<CitationStyle>("vancouver");
  const [busy, setBusy] = useState<"loading" | "formulate" | null>("loading");
  const [notice, setNotice] = useState<string | null>(null);
  const [source, setSource] = useState<string>("rules");
  const [editingComp, setEditingComp] = useState<boolean>(false);
  const [compInput, setCompInput] = useState<string>("");

  // Collect literature keywords from Step 2 evidence map
  const getLiteratureKeywords = useCallback((): string[] => {
    const gapSnapshot = sget<GapSnapshot>(KEYS.gap);
    const kw: string[] = [];
    if (gapSnapshot) {
      if (gapSnapshot.topic) kw.push(gapSnapshot.topic);
      if (Array.isArray(gapSnapshot.known)) {
        gapSnapshot.known.forEach(k => {
          if (k?.point) kw.push(k.point);
          if (Array.isArray(k?.references)) {
            k.references.forEach(r => { if (r?.title) kw.push(r.title); });
          }
        });
      }
      if (Array.isArray(gapSnapshot.uncertain)) {
        gapSnapshot.uncertain.forEach(u => {
          if (u?.point) kw.push(u.point);
          if (Array.isArray(u?.references)) {
            u.references.forEach(r => { if (r?.title) kw.push(r.title); });
          }
        });
      }
      if (Array.isArray(gapSnapshot.gaps)) {
        gapSnapshot.gaps.forEach(g => { if (g?.gap) kw.push(g.gap); });
      }
    }
    return kw;
  }, []);

  const finishAndGo = useCallback((f: Formulation, chosenOutcome: string) => {
    const str = (v: unknown): string => (typeof v === "string" ? v : "");
    const normElement = (v: unknown): { label: string; value: string } | null => {
      const o = v as { label?: unknown; value?: unknown };
      if (!o || typeof o !== "object") return null;
      const label = str(o.label) || "Element";
      const value = str(o.value);
      return value ? { label, value } : null;
    };
    const normScore = (v: unknown): { name: string; value: number } | null => {
      const o = v as { name?: unknown; value?: unknown };
      const name = str(o?.name);
      const value = typeof o?.value === "number" ? o.value : Number(str(o.value)) || 0;
      return name ? { name, value } : null;
    };
    const normVariant = (v: unknown): { question: string; rationale: string } | null => {
      const o = v as { question?: unknown; rationale?: unknown };
      const question = str(o?.question);
      return question ? { question, rationale: str(o?.rationale) } : null;
    };
    const normAdvisory = (v: unknown): string => {
      if (typeof v === "string" && v.trim()) return v;
      const o = v as { warning?: unknown; recommendation?: unknown; rationale?: unknown };
      if (o && typeof o === "object") {
        const bits = [
          str(o.warning),
          o.recommendation ? `Recommended: ${str(o.recommendation)}` : "",
          str(o.rationale)
        ].filter(Boolean);
        return bits.join(" ");
      }
      return "";
    };

    f.scores = Array.isArray(f.scores)
      ? f.scores.map(normScore).filter((s): s is { name: string; value: number } => !!s) : [];
    if (!f.scores.length) f.scores = [{ name: "Overall", value: 15 }];
    f.elements = Array.isArray(f.elements)
      ? f.elements.map(normElement).filter((e): e is { label: string; value: string } => !!e) : [];
    f.advisories = Array.isArray(f.advisories)
      ? f.advisories.map(normAdvisory).filter(Boolean) : [];
    f.variants = Array.isArray(f.variants)
      ? f.variants.map(normVariant).filter((v): v is { question: string; rationale: string } => !!v) : [];

    sset(KEYS.formulation, f);
    sset(KEYS.outcomes, [chosenOutcome]);
    sset("cq_outcome", chosenOutcome);
    sset(KEYS.citationStyle, citationStyle);
    if (typeof window !== "undefined") {
      window.sessionStorage.removeItem(KEYS.commentary);
    }
    router.push("/paper");
  }, [citationStyle, router]);

  // Formulate PICO and navigate immediately to Step 4
  const proceedToCommentary = useCallback(async (chosenOutcome: string) => {
    if (!extractedPico || !chosenOutcome) return;
    setBusy("formulate");

    const a: Analysis = {
      specialty: extractedPico.specialty,
      specialtyLabel: KB[extractedPico.specialty].label,
      condition: extractedPico.condition,
      intervention: extractedPico.intervention,
      comparator: extractedPico.comparator,
      questionType: "Therapy / Prevention",
      framework: "PICO",
      missing: [],
      interpretation: `PICO targeting ${extractedPico.condition} with ${extractedPico.intervention} vs ${extractedPico.comparator}`,
      source: "rules"
    };

    const ans: Record<string, string> = {
      condition: extractedPico.condition,
      intervention: extractedPico.intervention,
      comparator: extractedPico.comparator,
      outcome: chosenOutcome
    };

    const { ruleFormulate } = await import("@/lib/rule-engine");
    let f: Formulation = ruleFormulate(a, ans);

    try {
      const res = await fetch("/api/engine", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          stage: "formulate",
          analysis: a,
          answered: ans,
          selectedQuestion: extractedPico.cleanQuestion
        }),
        signal: AbortSignal.timeout(8000)
      });
      if (res.ok) {
        const parsed = await res.json();
        if (parsed && parsed.finalQuestion && !parsed.error) {
          f = parsed;
        }
      }
    } catch {
      // ruleFormulate fallback is already complete and verified
    }

    finishAndGo(f, chosenOutcome);
  }, [extractedPico, finishAndGo]);

  useEffect(() => {
    let isCancelled = false;
    const timer = setTimeout(() => {
      if (isCancelled) return;
      try {
        const question = sget<string>(KEYS.question);
        const gapSnapshot = sget<GapSnapshot & { source?: string }>(KEYS.gap);
        if (gapSnapshot?.source) setSource(gapSnapshot.source);
        const normalized = sget<string>(KEYS.inputText);
        const stored = readSessionInput(sget<unknown>(KEYS.input));
        const fallbackText = question
          || gapSnapshot?.suggestedQuestions?.[0]?.question
          || normalized
          || (stored ? sessionSearchText(stored) : "");

        if (!fallbackText) {
          router.replace("/");
          return;
        }

        // Extract guaranteed P, I, C, O elements from selected PICO question and evidence map
        const pico = extractPicoFromQuestion(
          fallbackText,
          gapSnapshot?.topic || normalized || "",
          gapSnapshot?.specialty as SpecialtyKey | undefined
        );
        setExtractedPico(pico);

        // Build literature-grounded outcome options
        const literatureKw = getLiteratureKeywords();
        const context = buildOutcomeContext(
          {
            specialty: pico.specialty,
            condition: pico.condition,
            intervention: pico.intervention,
            comparator: pico.comparator,
            questionType: "Therapy / Prevention"
          },
          {},
          {
            originalInput: normalized || gapSnapshot?.topic || fallbackText,
            population: pico.condition,
            keywords: literatureKw
          }
        );

        const selection = selectOutcomes(context);
        let options: RenderedOutcome[] = selection.options.map(o => ({
          id: o.id,
          label: o.label,
          category: o.category,
          rationale: o.rationale
        }));

        // Ensure 4 to 6 options are present
        if (options.length < 4) {
          const ranked = KB[pico.specialty].outcomesRanked;
          for (const r of ranked) {
            if (!options.some(o => o.label.toLowerCase() === r.toLowerCase())) {
              options.push({
                id: r.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
                label: r,
                category: "clinical",
                rationale: `Standard outcome for ${KB[pico.specialty].label} clinical questions.`
              });
            }
            if (options.length >= 6) break;
          }
        }
        options = options.slice(0, 6);

        setOutcomeOptions(options);
        setRecommendedId(selection.recommendedOutcome.id);
        setRecommendedRationale(selection.recommendedOutcome.rationale);

        // Pre-select the outcome matching the selected PICO question so card equals question outcome
        const qOutcome = pico?.outcome?.toLowerCase().trim();
        const matchingCard = qOutcome
          ? options.find(o => o.label.toLowerCase() === qOutcome || o.id.toLowerCase() === qOutcome.replace(/[^a-z0-9]+/g, "-"))
          : null;
        const initialPick = matchingCard?.label || options.find(o => o.id === selection.recommendedOutcome.id)?.label || options[0]?.label || "";
        setSelectedOutcome(initialPick);

        const storedStyle = sget<CitationStyle>(KEYS.citationStyle);
        if (storedStyle && (storedStyle === "vancouver" || storedStyle === "apa" || storedStyle === "harvard")) {
          setCitationStyle(storedStyle);
        }

        setBusy(null);
      } catch (err: unknown) {
        setNotice(err instanceof Error ? err.message : "Error extracting clinical outcomes.");
        setBusy(null);
      }
    }, 0);

    return () => {
      isCancelled = true;
      clearTimeout(timer);
    };
  }, [getLiteratureKeywords, router]);

  return (
    <div className="wrap">
      <header className="hdr">
        <h1>🎯 Step 3 · Select Clinical Outcome</h1>
        <p>Selected PICO question loaded from Evidence Map — choose 1 outcome to generate your commentary paper</p>
      </header>

      <main id="main" className="solo">
        {extractedPico && (
          <section className="card">
            <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
              <span className="pill">💡 Target PICO Question · {KB[extractedPico.specialty]?.label || "Obstetrics & Gynecology"}</span>
              <span className="pill" style={{ background: source === "ai" ? "#ecfdf5" : "#f1f5f9", color: source === "ai" ? "#065f46" : "#475569", fontWeight: 600 }}>
                {source === "ai" ? "🤖 AI-assisted" : "📋 Template (no AI)"}
              </span>
            </div>
            <div className="final-q" style={{ marginTop: 6, marginBottom: 12 }}>
              <b>{extractedPico.cleanQuestion}</b>
            </div>
            <div className="row" style={{ gap: 8, marginTop: 4, alignItems: "center", flexWrap: "wrap" }}>
              <span className="tag" title="Population">👥 <b>P:</b> {extractedPico.condition}</span>
              <span className="tag" title="Intervention">💊 <b>I:</b> {extractedPico.intervention}</span>
              {!editingComp ? (
                <span className="tag" title="Comparator" style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                  ⚖️ <b>C:</b> {extractedPico.comparator}
                  {extractedPico.inferredComparator && (
                    <span style={{ fontStyle: "italic", opacity: 0.85, fontSize: "0.85rem" }}>(assumed)</span>
                  )}
                  <button
                    type="button"
                    style={{ background: "none", border: "none", padding: "0 2px", cursor: "pointer", fontSize: "0.85rem", color: "#2563eb" }}
                    onClick={() => { setCompInput(extractedPico.comparator); setEditingComp(true); }}
                    title="Edit comparator"
                  >
                    ✏️
                  </button>
                </span>
              ) : (
                <div style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
                  <input
                    type="text"
                    value={compInput}
                    onChange={e => setCompInput(e.target.value)}
                    style={{ padding: "4px 8px", fontSize: "0.85rem", borderRadius: 4, border: "1px solid #94a3b8" }}
                    placeholder="Enter comparator"
                  />
                  <button
                    type="button"
                    className="secondary"
                    style={{ padding: "2px 8px", fontSize: "0.8rem" }}
                    onClick={() => {
                      if (compInput.trim()) {
                        setExtractedPico({
                          ...extractedPico,
                          comparator: compInput.trim(),
                          inferredComparator: false
                        });
                      }
                      setEditingComp(false);
                    }}
                  >
                    Save
                  </button>
                  <button
                    type="button"
                    className="secondary"
                    style={{ padding: "2px 8px", fontSize: "0.8rem" }}
                    onClick={() => setEditingComp(false)}
                  >
                    Cancel
                  </button>
                </div>
              )}
            </div>
          </section>
        )}

        {notice && (
          <section className="card"><div className="advisory">⚠️ {notice}</div></section>
        )}

        {outcomeOptions.length > 0 && busy !== "formulate" && (
          <section className="card">
            <h3 className="sec-h" style={{ marginTop: 0 }}>
              📋 Literature-Derived Outcomes — Click 1 to continue (No manual typing needed)
            </h3>
            <p className="hint">
              These 4–6 outcomes are ranked by clinical importance (suggested outcomes — verify against the relevant published core outcome set). Click an outcome card below to select it.
            </p>

            <div className="chips outcome-chips" role="group" aria-label="Outcome options" style={{ marginTop: 14 }}>
              {outcomeOptions.map(opt => {
                const isSel = selectedOutcome === opt.label;
                const isRec = opt.id === recommendedId;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    className={`chip outcome-chip ${isSel ? "chip-on" : ""} ${isRec ? "chip-recommended" : ""}`}
                    aria-pressed={isSel}
                    aria-label={`${opt.label}${isRec ? ", recommended primary outcome" : ""}`}
                    onClick={() => setSelectedOutcome(opt.label)}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between", width: "100%", alignItems: "center" }}>
                      <span className="outcome-chip-label">{opt.label}</span>
                      {isSel && (
                        <span style={{ fontWeight: 700, fontSize: "0.85rem", color: isSel ? "#fff" : "inherit" }}>
                          ✓ Selected
                        </span>
                      )}
                    </div>
                    <span className="outcome-chip-meta">
                      {isRec && <span className="outcome-badge">Recommended</span>}
                      <span className="outcome-category">{opt.category.replace(/-/g, " ")}</span>
                    </span>
                    <span className="outcome-why">{opt.rationale}</span>
                  </button>
                );
              })}
            </div>

            {recommendedRationale && (
              <p className="hint" style={{ marginTop: 14 }}>
                💡 <b>Evidence Grounding:</b> {recommendedRationale}
              </p>
            )}

            <div style={{ marginTop: 20, paddingTop: 16, borderTop: "1px solid var(--border, #e2e8f0)" }}>
              <h4 style={{ margin: "0 0 8px 0", fontSize: "0.95rem", color: "var(--text-muted, #64748b)" }}>
                ✏️ Or Enter a Custom Outcome (Optional)
              </h4>
              <p className="hint" style={{ marginBottom: 10 }}>
                If you prefer an endpoint not listed in the cards above, type it below and click Continue.
              </p>
              <div className="row" style={{ gap: 10, alignItems: "center" }}>
                <input
                  className="free-input"
                  type="text"
                  aria-label="Custom clinical outcome"
                  value={customOutcome}
                  onChange={(e) => setCustomOutcome(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && customOutcome.trim()) {
                      e.preventDefault();
                      proceedToCommentary(customOutcome.trim());
                    }
                  }}
                  placeholder="e.g., spontaneous preterm birth before 32 weeks, neonatal ICU stay..."
                  style={{ flex: 1, padding: "10px 14px" }}
                />
                <button
                  className="secondary"
                  style={{ whiteSpace: "nowrap", padding: "10px 18px" }}
                  disabled={!customOutcome.trim() || !!busy}
                  onClick={() => customOutcome.trim() && proceedToCommentary(customOutcome.trim())}
                >
                  Select Custom Outcome ➜
                </button>
              </div>
            </div>

            <div style={{ marginTop: 24, paddingTop: 18, borderTop: "1px solid var(--border, #e2e8f0)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                <h4 style={{ margin: 0, fontSize: "1.05rem", color: "#0f766e", fontWeight: 700 }}>
                  📖 Citation & Reference Style for PDF & Word Export
                </h4>
                <span className="pill" style={{ background: "#ccfbf1", color: "#0f766e", fontSize: "0.8rem", fontWeight: 600 }}>
                  Active: {citationStyle === "vancouver" ? "Vancouver (superscript numerals)" : citationStyle.toUpperCase()}
                </span>
              </div>
              <p className="hint" style={{ marginBottom: 12 }}>
                Select how citations in the text narrative and the final reference list should be formatted in your publication deliverables:
              </p>

              <div
                className="citation-style-options"
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
                  gap: 12,
                  marginTop: 10
                }}
              >
                {/* 1. Vancouver */}
                <button
                  type="button"
                  aria-pressed={citationStyle === "vancouver"}
                  className={`chip outcome-chip ${citationStyle === "vancouver" ? "chip-on" : ""}`}
                  style={{ textAlign: "left", padding: "14px 16px", cursor: "pointer", height: "auto" }}
                  onClick={() => setCitationStyle("vancouver")}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", marginBottom: 4 }}>
                    <strong style={{ fontSize: "0.98rem" }}>1. Vancouver (ICMJE/NLM)</strong>
                    <span className="outcome-badge" style={{ background: "#0f766e", color: "#fff" }}>Recommended</span>
                  </div>
                  <div style={{ fontSize: "0.84rem", opacity: 0.9, lineHeight: 1.4 }}>
                    <b>In-Text:</b> Uppercase superscript with <b>NO brackets</b> (¹, ² or 1, 2)
                  </div>
                  <div style={{ fontSize: "0.8rem", color: citationStyle === "vancouver" ? "#e0f2fe" : "#64748b", marginTop: 4 }}>
                    <b>References:</b> Sequential numbered bibliography. Standard in clinical and medical journals.
                  </div>
                </button>

                {/* 2. APA */}
                <button
                  type="button"
                  aria-pressed={citationStyle === "apa"}
                  className={`chip outcome-chip ${citationStyle === "apa" ? "chip-on" : ""}`}
                  style={{ textAlign: "left", padding: "14px 16px", cursor: "pointer", height: "auto" }}
                  onClick={() => setCitationStyle("apa")}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", marginBottom: 4 }}>
                    <strong style={{ fontSize: "0.98rem" }}>2. APA (7th Edition)</strong>
                    {citationStyle === "apa" && <span style={{ fontWeight: 700, fontSize: "0.85rem", color: "#fff" }}>✓ Selected</span>}
                  </div>
                  <div style={{ fontSize: "0.84rem", opacity: 0.9, lineHeight: 1.4 }}>
                    <b>In-Text:</b> Author-date parentheses: <i>(Owen &amp; Hankins, 2020)</i>
                  </div>
                  <div style={{ fontSize: "0.8rem", color: citationStyle === "apa" ? "#e0f2fe" : "#64748b", marginTop: 4 }}>
                    <b>References:</b> Alphabetical list by author surname with year in parentheses.
                  </div>
                </button>

                {/* 3. Harvard */}
                <button
                  type="button"
                  aria-pressed={citationStyle === "harvard"}
                  className={`chip outcome-chip ${citationStyle === "harvard" ? "chip-on" : ""}`}
                  style={{ textAlign: "left", padding: "14px 16px", cursor: "pointer", height: "auto" }}
                  onClick={() => setCitationStyle("harvard")}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", marginBottom: 4 }}>
                    <strong style={{ fontSize: "0.98rem" }}>3. Harvard Style</strong>
                    {citationStyle === "harvard" && <span style={{ fontWeight: 700, fontSize: "0.85rem", color: "#fff" }}>✓ Selected</span>}
                  </div>
                  <div style={{ fontSize: "0.84rem", opacity: 0.9, lineHeight: 1.4 }}>
                    <b>In-Text:</b> Author-year format: <i>(Owen and Hankins 2020)</i>
                  </div>
                  <div style={{ fontSize: "0.8rem", color: citationStyle === "harvard" ? "#e0f2fe" : "#64748b", marginTop: 4 }}>
                    <b>References:</b> Alphabetical bibliography with full publisher details.
                  </div>
                </button>
              </div>
            </div>

            <div className="row" style={{ marginTop: 22 }}>
              <button
                className="primary"
                style={{ padding: "14px 30px", fontSize: "1.05rem", fontWeight: 600 }}
                disabled={!selectedOutcome || !!busy}
                onClick={() => selectedOutcome && proceedToCommentary(selectedOutcome)}
              >
                {selectedOutcome
                  ? `Generate Scientific Commentary with "${selectedOutcome}" (${citationStyle === "vancouver" ? "Vancouver Style" : citationStyle.toUpperCase()}) ➜`
                  : "Click an outcome card above to continue ➜"}
              </button>
            </div>

            <p className="hint" style={{ marginTop: 8 }} aria-live="polite">
              {selectedOutcome
                ? `Selected outcome: "${selectedOutcome}" · Citation style: ${citationStyle.toUpperCase()}. Click above to generate your Step 4 Scientific Commentary Paper.`
                : "Select one outcome card above to proceed."}
            </p>
          </section>
        )}

        {busy === "loading" && (
          <section className="card">
            <AnimatedProcessingIndicator
              message="Extracting PICO parameters & literature outcomes…"
              secondaryMessage="Analyzing PubMed evidence to curate relevant clinical endpoints."
            />
          </section>
        )}

        {busy === "formulate" && (
          <section className="card">
            <AnimatedProcessingIndicator
              message="Formulating clinical question & evidence parameters…"
              secondaryMessage="Preparing Vancouver-style commentary generation."
            />
          </section>
        )}

        <div className="row" style={{ marginTop: 16 }}>
          <button className="link" onClick={() => router.push("/gap")}>← Back to Evidence Map</button>
          <button className="link" onClick={() => { resetSession(); router.replace("/"); }}>← Start over</button>
        </div>
      </main>

      <footer>Version 3.1 · Copyright©RaoufRoshdy2026</footer>
    </div>
  );
}
